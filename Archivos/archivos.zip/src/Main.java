public class Main {
    public static void main(String[] args) {
        Archivos archivos = new Archivos();

    }
}
